Cufon.replace('h1', { fontFamily: 'Humanst521 Lt BT', color: '-linear-gradient(#ffffff, #cccccc)' });;
Cufon.replace('header nav a', { fontFamily: 'Humanst521 Lt BT', textShadow: '1px 1px rgba(0, 0, 0, 0.2)' });;
Cufon.replace('h2', { fontFamily: 'Humanst521 Lt BT'});;
Cufon.replace('.news li figure', { fontFamily: 'Humanst521 BT'});;